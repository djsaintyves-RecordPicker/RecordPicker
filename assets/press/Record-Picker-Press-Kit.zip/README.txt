RECORD PICKER 2.6 - PRESS KIT

Record Picker is available on iPhone, iPad, Apple Watch, Mac and Windows 11.
Android remains in development.

App Store: https://apps.apple.com/app/id6780422305
Microsoft Store: https://apps.microsoft.com/detail/9N2ZWRL4M3JC
Website: https://recordpicker.app/
Press contact: Yves Durand - djsaintyves@mac.com
